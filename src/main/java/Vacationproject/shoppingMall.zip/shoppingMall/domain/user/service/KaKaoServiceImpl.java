package Vacationproject.shoppingMall.domain.user.service;

public class KaKaoServiceImpl {
}
