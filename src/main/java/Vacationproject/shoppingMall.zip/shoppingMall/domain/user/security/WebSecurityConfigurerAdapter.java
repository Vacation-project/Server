package Vacationproject.shoppingMall.domain.user.security;

public class WebSecurityConfigurerAdapter {
}
