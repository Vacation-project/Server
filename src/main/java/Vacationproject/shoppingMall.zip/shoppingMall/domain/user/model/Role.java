package Vacationproject.shoppingMall.domain.user.model;

public enum Role {
    USER, ADMIN
}
