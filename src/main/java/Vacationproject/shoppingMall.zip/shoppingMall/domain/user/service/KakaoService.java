package Vacationproject.shoppingMall.domain.user.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 키카오 인증에 필요한 서비스 로직을 구현
 */

@Service
@RequiredArgsConstructor
@Slf4j
public interface KakaoService {


}