package Vacationproject.shoppingMall.config;

public class WebConfig {
}
